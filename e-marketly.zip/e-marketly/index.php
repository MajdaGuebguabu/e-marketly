<script>
    
    window.location.href = '/home.php';
</script>